export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  children?: NavigationItem[];
  role?: string[];
  isMainParent?: boolean;
}

export const NavigationItems: NavigationItem[] = [
  {
    id: 'dashboard',
    title: 'Dashboard',
    type: 'group',
    icon: 'icon-navigation',
    children: [
      {
        id: 'default',
        title: 'Dashboard',
        type: 'item',
        classes: 'nav-item',
        url: '/default',
        icon: 'fa fa-dashboard',
        breadcrumbs: false
      }
    ]
  },
  {
    id: 'page',
    title: 'DATAX',
    type: 'group',
    icon: 'icon-navigation',
    children: [
      {
        id: 'Authentication',
        title: 'REQUEST FORMS',
        type: 'collapse',
        icon: 'fa fa-key',
        children: [
          {
            id: 'DXR',
            title: 'DXR',
            type: 'item',
            url: '/guest/login',
            target: true,
            breadcrumbs: false
          },
          {
            id: 'GWIM',
            title: 'GWIM VERIFICATION',
            type: 'item',
            url: '/guest/register',
            target: true,
            breadcrumbs: false
          }
        ]
      }
    ]
  },
  {
    id: 'sdg',
    title: 'SDG',
    icon: 'icon-navigation',
    type: 'group',
    children: [
      {
        id: 'default',
        title: 'New request',
        type: 'item',
        classes: 'nav-item',
        url: '/default',
        icon: 'fa fa-pencil',
        breadcrumbs: true
      }
    ]
  }

];
